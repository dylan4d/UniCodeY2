public class LoanAccount extends BankAccount {
    private int _overdraftLimit;
    private final int _accNum;
    private int _balance;
    private Person _person;

    public LoanAccount(int accNum, Person person, int balance, int overdraftLimit){
        super(accNum, person, balance);
        this._accNum = accNum;
        this._balance = balance;
        this._person = person;
        this._overdraftLimit = overdraftLimit;
    }

    @Override
    public String toString(){
        return this._person.get_first() + " " +  this._person.get_last() + " with bank account number:" + this._accNum + "with balance:" + this._balance + ".";
    }

    public String display(){
        return super.display() + "They have overdraft limit: " + _overdraftLimit + ".\n";
    }

    //getters
    public int get_overdraftLimit() {
        return _overdraftLimit;
    }

    //setters
    public void set_overdraftLimit(int _overdraftLimit) {
        this._overdraftLimit = _overdraftLimit;
    }
}