public class Vegetable implements Food{

    private String _name;
    private int _kCal;
    private double _protein;
    private double _fat;
    private double _vitaminA;
    private double _vitaminB;
    private double _vitaminC;

    public Vegetable(String name, int kCal, double protein, double fat, double vitaminA, double vitaminB, double vitaminC){
        this._name = name;
        this._kCal = kCal;
        this._protein = protein;
        this._fat = fat;
        this._vitaminA = vitaminA;
        this._vitaminB = vitaminB;
        this._vitaminC = vitaminC;
    }

    @Override
    public String getName() {
        return this._name;
    }

    @Override
    public int getkCals() {
        return this._kCal;
    }

    @Override
    public double getProtein() {
        return this._protein;
    }

    @Override
    public double getFat() {
        return this._fat;
    }

    @Override
    public double getVitaminA() {
        return this._vitaminA;
    }

    @Override
    public double getVitaminB() {
        return this._vitaminB;
    }

    @Override
    public double getVitaminC() {
        return this._vitaminC;
    }

    @Override
    public boolean healthy() {
        /*
        function that returns if a vegetable is healthy or not
        */
        if (_vitaminA + _vitaminB + _vitaminC > _kCal + _fat){
            return true;
        }
        return false;
    }

    @Override
    public void display() {
    }
    
}
