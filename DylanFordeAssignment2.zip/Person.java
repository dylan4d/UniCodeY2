public class Person {
    private String _first;
    private String _last;
    private String _address;
    private Meat _favouriteMeat;
    private Vegetable _favouriteVegetable;

    public Person(String first, String last, String address){
        this._first = first;
        this._last = last;
        this._address = address;
    }

    @Override
    public String toString(){
        return _first + " " + _last + " living at " + _address + "."; 
    }

    public String display(){
        return this._first + " " +  this._last + " lives at " + this._address + ".";
    }

    //getters
    public String get_first() {
        return _first;
    }

    public String get_last() {
        return _last;
    }

    public String get_address() {
        return _address;
    }

    public void setFavouriteMeat(Meat kind){
        this._favouriteMeat = kind;
    }

    public void setFavouriteVegetable(Vegetable kind){
        this._favouriteVegetable = kind;
    }

    public boolean favouriteMeatHealthy(){
        if (_favouriteMeat != null){
            return _favouriteMeat.healthy();
        }
        return false;
    }
    public boolean favouriteVegetableHealthy(){
        if (_favouriteVegetable != null){
            return _favouriteVegetable.healthy();
        }
        return false;
    }
}