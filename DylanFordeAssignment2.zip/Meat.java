public class Meat implements Food {
    private String _name;
    private int _kCals;
    private double _protein;
    private double _fat;
    private double _vitaminA;
    private double _vitaminB;
    private double _vitaminC;

    public Meat(String name, int kCals, double protein, double fat, double vitaminA, double vitaminB, double vitaminC){
        this._name = name;
        this._kCals = kCals;
        this._protein = protein;
        this._fat = fat;
        this._vitaminA = vitaminA;
        this._vitaminB = vitaminB;
        this._vitaminC = vitaminC;
    }

    //getters
    @Override
    public String getName() {
        return this._name;
    }

    @Override
    public int getkCals() {
        return this._kCals;
    }

    @Override
    public double getProtein() {
        return this._protein;
    }

    @Override
    public double getFat() {
        return this._fat;
    }

    @Override
    public double getVitaminA() {
        return this._vitaminA;
    }

    @Override
    public double getVitaminB() {
        return this._vitaminB;
    }

    @Override
    public double getVitaminC() {
        return this._vitaminC;
    }

    //methods
    @Override
    public boolean healthy() {
        /* 
        function that returns if a meat is healthy or unhealthy
        */
        if (_vitaminA + _vitaminB + _vitaminC + _protein > _fat){
            return true;
        }
        return false;
    }

    @Override
    public void display() {
    }
    
}
