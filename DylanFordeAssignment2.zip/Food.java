public interface Food {
    public String getName();
    public int getkCals();
    public double getProtein();
    public double getFat();
    public double getVitaminA();
    public double getVitaminB();
    public double getVitaminC();
    public boolean healthy();
    public void display();   
}
