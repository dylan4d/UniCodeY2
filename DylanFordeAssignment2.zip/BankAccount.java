import java.util.ArrayList;

public class BankAccount {
    private final int _accNum;
    private int _balance;
    private Person _person;
    private static ArrayList<Integer> _ensureNoSameBankAccountNumbers = new ArrayList<Integer>();

    public BankAccount(int accNum, Person person, int balance){
        this._accNum = accNum;
        this._balance = balance;
        this._person = person;
        
        if (_ensureNoSameBankAccountNumbers.isEmpty()){
            _ensureNoSameBankAccountNumbers.add(this._accNum);
        } else if (_ensureNoSameBankAccountNumbers.contains(_accNum)){
            System.out.println("This is an invalid account number, it is already taken.");
            throw new IllegalArgumentException();
        } else {
            System.out.println("This bank account has been created");
            _ensureNoSameBankAccountNumbers.add(this._accNum);
        }

    }

    @Override
    public String toString(){
        return _person.get_first() + " " + _person.get_last() + " with account number: " + get_accNum() +". Has bank account balance: " + get_balance() + ".";
    }

    public String display(){
        return _person.display() + "Their bank account number: " + _accNum + " and their balance: " + _balance + ".\n";

    }

    //getters
    public int get_accNum() {
        return _accNum;
    }

    public int get_balance() {
        return _balance;
    }

    public Person get_person() {
        return _person;
    }

    public static ArrayList<Integer> get_ensureNoSameBankAccountNumbers() {
        return _ensureNoSameBankAccountNumbers;
    }

    //setters
    public void set_balance(int _balance) {
        this._balance = _balance;
    }

}