import java.util.ArrayList;

public class AccountTest {
    public static void main(String[] args){
        //instantiate people
        System.out.println("Instantiating people ---");
        Person p1 = new Person("Dylan", "Forde", "Cork");
        System.out.println(p1.display());

        Person p2 = new Person("John", "Doe", "somewhere in Cork");
        System.out.println(p2.display());

        Person p3 = new Person("Mary", "Lou", "somewhere in Cork");
        System.out.println(p3.display());

        Person p4 = new Person("George", "Washington", "George Washington Memorial");
        System.out.println(p4.display());
        System.out.println("\n");

        //instantiate accounts
        System.out.println("Instantiating bank accounts ---");
        BankAccount b1 = new BankAccount(1, p1, 10);
        System.out.println(b1.display());

        BankAccount b2 = new BankAccount(2, p3, 100);
        System.out.println(b2.display());

        LoanAccount l1 = new LoanAccount(3, p2, 100, 1000);
        System.out.println(l1.display());

        LoanAccount l2 = new LoanAccount(4, p4, 10000, 100);
        System.out.println(l2.display());

        LoanAccount l3 = new LoanAccount(5, p1, 100000, 10000);
        System.out.println(l3.display());
        System.out.println("\n");

        //Tests for Equals
        System.out.println("These are tests for equals ---");
        System.out.println(p1.equals(p2)); //should be false
        System.out.println(p1.equals(p1)); //should be true
        System.out.println(p1.equals(p2)); //should be false

        //Tests for Person
        System.out.println("These are tests for Person methods");
        System.out.println(p1.toString());
        System.out.println(p2.toString());
        System.out.println(p1.get_first() + " " + p1.get_last() + " in" + p1.get_address());
        
        //Tests for BankAccount
        System.out.println(b1.toString());
        System.out.println(b2.toString());
        System.out.println(b1.get_person());
        System.out.println("Account Number: " + b1.get_accNum() + "\nAccount Balance: " + b1.get_balance() + ".");

        //Tests for LoanAccount
        System.out.println(l1.display());
        System.out.println(l2.display());

        //Test for favourite food
        Meat m1 = new Meat("steak", 271, 25, 19, 25, 2.2, 0);
        p1.setFavouriteMeat(m1);
        Vegetable v1 = new Vegetable("potato", 77, 1.9, 0.1, 2, 0, 19.7);
        p2.setFavouriteVegetable(v1);
        
        System.out.println(p1.favouriteMeatHealthy());
        System.out.println(p2.favouriteVegetableHealthy());

        ArrayList<Person> foodList = new ArrayList<Person>();
        foodList.add(p1);
        foodList.add(p2);
        for (Person person : foodList) {
            System.out.println("Is my favourite food healthy?");
            System.out.println(person.favouriteMeatHealthy());
            System.out.println(person.favouriteVegetableHealthy());
        }

        //Test for Exceptions
        System.out.println("Exception Tests---");
        try {
            BankAccount b3 = new BankAccount(1, p2, 10);
            System.out.println(b3.display());
        } catch (IllegalArgumentException e) {
            System.out.println(e);
            System.out.println("This account number has already been used.");
        }
    }

}